<?php echo e($slot); ?>

<?php /**PATH D:\projetos\onfly\src\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>